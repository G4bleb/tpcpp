Compiler avec une version de Qt supérieure à 5.8

Commandes : • qmake     Il se situe dans Qt/[VERSION]/gcc_64/bin/qmake
            • make
